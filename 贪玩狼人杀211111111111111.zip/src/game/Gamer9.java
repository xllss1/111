package game;

public class Gamer9 {

    private boolean islive;//是否活着
    private boolean people;//是否是好人
    private String id;//身份

    private boolean duyao;//是否有毒药
    private boolean jieyao;//是否有解药

    /**
     * 构造方法
     */
    public Gamer9(){
        islive = true;
        people = false;
        jieyao = false;

    }



    //get和set方法

    public boolean getislive() {
        return islive;
    }

    public boolean getpeople() {
        return people;
    }

    public String getid() {
        return id;
    }

    public boolean getduyao() {
        return duyao;
    }

    public boolean getjieyao() {
        return jieyao;
    }




    public void setislive(boolean live) {
        islive = live;
    }

    public void setpeople(boolean good) {
        people = good;
    }

    public void setid(String idis) {
        this.id = idis;
    }

    public void setduyao(boolean yduyao) {
        duyao = yduyao;
    }

    public void setjieyao(boolean yjieyao) {
        jieyao = yjieyao;
    }

   
}

