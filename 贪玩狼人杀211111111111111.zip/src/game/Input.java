package game;

import java.util.Scanner;

import go.game6;
import go.game61;
import go.game62;
import go.game63;
import go.game64;
import go.game65;

public class Input {

	 public static int inputOption(int zuixiao, int zuida, String tishi, String cuowu){


			game6.msg+="-----+++++-----+++++-----+++++-----";
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);
	        game6.msg+=tishi;
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);

	        game61.msg+="-----+++++-----+++++-----+++++-----";
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);
	        game61.msg+=tishi;
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);

	        game62.msg+="-----+++++-----+++++-----+++++-----";
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);
	        game62.msg+=tishi;
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);

	        game63.msg+="-----+++++-----+++++-----+++++-----";
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);
	        game63.msg+=tishi;
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);

	        game64.msg+="-----+++++-----+++++-----+++++-----";
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);
	        game64.msg+=tishi;
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);

	        game65.msg+="-----+++++-----+++++-----+++++-----";
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        game65.msg+=tishi;
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        int option = 0;
	        int a;
	        while(true) {
	            a=Integer.parseInt(game6.shu);
	            if(a==-1) {
	             System.out.println(cuowu);
	             System.out.println("cxsr");
	             try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            }else break;
	           }
	        
	        

	        while(true) {
	        	
	        	option=Integer.parseInt(game6.shu);
	        	game6.shu=("-1");
	        	 if(option>zuida||option<zuixiao) {
	        		 
	    			game6.msg+=cuowu;
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	    			game6.msg+="cxsr";
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	        		 
	    			game61.msg+=cuowu;
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	    			game61.msg+="cxsr";
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	        		 
	    			game62.msg+=cuowu;
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	    			game62.msg+="cxsr";
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	        		 
	    			game63.msg+=cuowu;
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	    			game63.msg+="cxsr";
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	        		 
	    			game64.msg+=cuowu;
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	    			game64.msg+="cxsr";
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	        		 
	    			game65.msg+=cuowu;
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    			game65.msg+="cxsr";
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    	        
	    	        try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

	        	}else break;
	        }
	        return option;
	    }
	 public static int inputOption1(int zuixiao, int zuida, String tishi, String cuowu){


			game6.msg+="-----+++++-----+++++-----+++++-----";
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);
	        game6.msg+=tishi;
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);

	        game61.msg+="-----+++++-----+++++-----+++++-----";
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);
	        game61.msg+=tishi;
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);

	        game62.msg+="-----+++++-----+++++-----+++++-----";
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);
	        game62.msg+=tishi;
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);

	        game63.msg+="-----+++++-----+++++-----+++++-----";
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);
	        game63.msg+=tishi;
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);

	        game64.msg+="-----+++++-----+++++-----+++++-----";
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);
	        game64.msg+=tishi;
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);

	        game65.msg+="-----+++++-----+++++-----+++++-----";
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        game65.msg+=tishi;
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        int option = 0;
	        int a;
	        while(true) {
	            a=Integer.parseInt(game61.shu);
	            if(a==-1) {
	             System.out.println(cuowu);
	             System.out.println("cxsr");
	             try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            }else break;
	           }
	        
	        

	        while(true) {
	        	
	        	option=Integer.parseInt(game61.shu);
	        	game61.shu=("-1");
	        	 if(option>zuida||option<zuixiao) {
	        		 
	    			game6.msg+=cuowu;
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	    			game6.msg+="cxsr";
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	        		 
	    			game61.msg+=cuowu;
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	    			game61.msg+="cxsr";
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	        		 
	    			game62.msg+=cuowu;
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	    			game62.msg+="cxsr";
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	        		 
	    			game63.msg+=cuowu;
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	    			game63.msg+="cxsr";
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	        		 
	    			game64.msg+=cuowu;
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	    			game64.msg+="cxsr";
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	        		 
	    			game65.msg+=cuowu;
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    			game65.msg+="cxsr";
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    	        
	    	        try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

	        	}else break;
	        }
	        return option;
	    }
	 public static int inputOption2(int zuixiao, int zuida, String tishi, String cuowu){


			game6.msg+="-----+++++-----+++++-----+++++-----";
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);
	        game6.msg+=tishi;
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);

	        game61.msg+="-----+++++-----+++++-----+++++-----";
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);
	        game61.msg+=tishi;
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);

	        game62.msg+="-----+++++-----+++++-----+++++-----";
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);
	        game62.msg+=tishi;
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);

	        game63.msg+="-----+++++-----+++++-----+++++-----";
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);
	        game63.msg+=tishi;
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);

	        game64.msg+="-----+++++-----+++++-----+++++-----";
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);
	        game64.msg+=tishi;
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);

	        game65.msg+="-----+++++-----+++++-----+++++-----";
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        game65.msg+=tishi;
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        int option = 0;
	        int a;
	        while(true) {
	            a=Integer.parseInt(game62.shu);
	            if(a==-1) {
	             System.out.println(cuowu);
	             System.out.println("cxsr");
	             try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            }else break;
	           }
	        
	        

	        while(true) {
	        	
	        	option=Integer.parseInt(game62.shu);
	        	game62.shu=("-1");
	        	 if(option>zuida||option<zuixiao) {
	        		 
	    			game6.msg+=cuowu;
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	    			game6.msg+="cxsr";
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	        		 
	    			game61.msg+=cuowu;
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	    			game61.msg+="cxsr";
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	        		 
	    			game62.msg+=cuowu;
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	    			game62.msg+="cxsr";
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	        		 
	    			game63.msg+=cuowu;
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	    			game63.msg+="cxsr";
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	        		 
	    			game64.msg+=cuowu;
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	    			game64.msg+="cxsr";
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	        		 
	    			game65.msg+=cuowu;
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    			game65.msg+="cxsr";
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    	        
	    	        try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

	        	}else break;
	        }
	        return option;
	    }
	 public static int inputOption3(int zuixiao, int zuida, String tishi, String cuowu){


			game6.msg+="-----+++++-----+++++-----+++++-----";
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);
	        game6.msg+=tishi;
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);

	        game61.msg+="-----+++++-----+++++-----+++++-----";
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);
	        game61.msg+=tishi;
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);

	        game62.msg+="-----+++++-----+++++-----+++++-----";
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);
	        game62.msg+=tishi;
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);

	        game63.msg+="-----+++++-----+++++-----+++++-----";
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);
	        game63.msg+=tishi;
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);

	        game64.msg+="-----+++++-----+++++-----+++++-----";
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);
	        game64.msg+=tishi;
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);

	        game65.msg+="-----+++++-----+++++-----+++++-----";
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        game65.msg+=tishi;
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        int option = 0;
	        int a;
	        while(true) {
	            a=Integer.parseInt(game63.shu);
	            if(a==-1) {
	             System.out.println(cuowu);
	             System.out.println("cxsr");
	             try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            }else break;
	           }
	        
	        

	        while(true) {
	        	
	        	option=Integer.parseInt(game63.shu);
	        	game63.shu=("-1");
	        	 if(option>zuida||option<zuixiao) {
	        		 
	    			game6.msg+=cuowu;
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	    			game6.msg+="cxsr";
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	        		 
	    			game61.msg+=cuowu;
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	    			game61.msg+="cxsr";
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	        		 
	    			game62.msg+=cuowu;
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	    			game62.msg+="cxsr";
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	        		 
	    			game63.msg+=cuowu;
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	    			game63.msg+="cxsr";
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	        		 
	    			game64.msg+=cuowu;
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	    			game64.msg+="cxsr";
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	        		 
	    			game65.msg+=cuowu;
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    			game65.msg+="cxsr";
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    	        
	    	        try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

	        	}else break;
	        }
	        return option;
	    }
	 public static int inputOption4(int zuixiao, int zuida, String tishi, String cuowu){


			game6.msg+="-----+++++-----+++++-----+++++-----";
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);
	        game6.msg+=tishi;
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);

	        game61.msg+="-----+++++-----+++++-----+++++-----";
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);
	        game61.msg+=tishi;
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);

	        game62.msg+="-----+++++-----+++++-----+++++-----";
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);
	        game62.msg+=tishi;
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);

	        game63.msg+="-----+++++-----+++++-----+++++-----";
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);
	        game63.msg+=tishi;
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);

	        game64.msg+="-----+++++-----+++++-----+++++-----";
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);
	        game64.msg+=tishi;
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);

	        game65.msg+="-----+++++-----+++++-----+++++-----";
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        game65.msg+=tishi;
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        int option = 0;
	        int a;
	        while(true) {
	            a=Integer.parseInt(game64.shu);
	            if(a==-1) {
	             System.out.println(cuowu);
	             System.out.println("cxsr");
	             try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            }else break;
	           }
	        
	        

	        while(true) {
	        	
	        	option=Integer.parseInt(game64.shu);
	        	game64.shu=("-1");
	        	 if(option>zuida||option<zuixiao) {
	        		 
	    			game6.msg+=cuowu;
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	    			game6.msg+="cxsr";
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	        		 
	    			game61.msg+=cuowu;
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	    			game61.msg+="cxsr";
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	        		 
	    			game62.msg+=cuowu;
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	    			game62.msg+="cxsr";
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	        		 
	    			game63.msg+=cuowu;
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	    			game63.msg+="cxsr";
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	        		 
	    			game64.msg+=cuowu;
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	    			game64.msg+="cxsr";
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	        		 
	    			game65.msg+=cuowu;
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    			game65.msg+="cxsr";
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    	        
	    	        try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

	        	}else break;
	        }
	        return option;
	    }
	 public static int inputOption5(int zuixiao, int zuida, String tishi, String cuowu){


			game6.msg+="-----+++++-----+++++-----+++++-----";
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);
	        game6.msg+=tishi;
	        game6.msg+="\n";
	        game6.t1.setText(game6.msg);

	        game61.msg+="-----+++++-----+++++-----+++++-----";
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);
	        game61.msg+=tishi;
	        game61.msg+="\n";
	        game61.t1.setText(game61.msg);

	        game62.msg+="-----+++++-----+++++-----+++++-----";
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);
	        game62.msg+=tishi;
	        game62.msg+="\n";
	        game62.t1.setText(game62.msg);

	        game63.msg+="-----+++++-----+++++-----+++++-----";
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);
	        game63.msg+=tishi;
	        game63.msg+="\n";
	        game63.t1.setText(game63.msg);

	        game64.msg+="-----+++++-----+++++-----+++++-----";
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);
	        game64.msg+=tishi;
	        game64.msg+="\n";
	        game64.t1.setText(game64.msg);

	        game65.msg+="-----+++++-----+++++-----+++++-----";
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        game65.msg+=tishi;
	        game65.msg+="\n";
	        game65.t1.setText(game65.msg);
	        int option = 0;
	        int a;
	        while(true) {
	            a=Integer.parseInt(game65.shu);
	            if(a==-1) {
	             System.out.println(cuowu);
	             System.out.println("cxsr");
	             try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            }else break;
	           }
	        
	        

	        while(true) {
	        	
	        	option=Integer.parseInt(game65.shu);
	        	game65.shu=("-1");
	        	 if(option>zuida||option<zuixiao) {
	        		 
	    			game6.msg+=cuowu;
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	    			game6.msg+="cxsr";
	    	        game6.msg+="\n";
	    	        game6.t1.setText(game6.msg);
	        		 
	    			game61.msg+=cuowu;
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	    			game61.msg+="cxsr";
	    	        game61.msg+="\n";
	    	        game61.t1.setText(game61.msg);
	        		 
	    			game62.msg+=cuowu;
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	    			game62.msg+="cxsr";
	    	        game62.msg+="\n";
	    	        game62.t1.setText(game62.msg);
	        		 
	    			game63.msg+=cuowu;
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	    			game63.msg+="cxsr";
	    	        game63.msg+="\n";
	    	        game63.t1.setText(game63.msg);
	        		 
	    			game64.msg+=cuowu;
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	    			game64.msg+="cxsr";
	    	        game64.msg+="\n";
	    	        game64.t1.setText(game64.msg);
	        		 
	    			game65.msg+=cuowu;
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    			game65.msg+="cxsr";
	    	        game65.msg+="\n";
	    	        game65.t1.setText(game65.msg);
	    	        
	    	        try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

	        	}else break;
	        }
	        return option;
	    }

}
