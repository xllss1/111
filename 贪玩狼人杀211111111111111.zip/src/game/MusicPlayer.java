
package game;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

/**
 * Java 播放音频
 * @ClassName: MusicPlayer   
 * @Description: TODO   
 * @author: hyacinth
 * @date: 2020年3月5日 上午12:10:53     
 * @Copyright: hyacinth
 */
public class MusicPlayer {
	public static String a;
	public static String b;
	
	static Player player = null;
	public static void main(String args[]) {
		try {
			bf(null);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JavaLayerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void bf(String[] args) throws FileNotFoundException, JavaLayerException {
		File file = new File(a);
		FileInputStream fis = new FileInputStream(file);
		BufferedInputStream stream = new BufferedInputStream(fis);
		Player player = new Player(stream);
		player.play();
		player.close();
		a=null;
	}
	public static void bf1(String[] args) throws FileNotFoundException, JavaLayerException {
		File file = new File(a);
		FileInputStream fis = new FileInputStream(file);
		BufferedInputStream stream = new BufferedInputStream(fis);
		Player player = new Player(stream);
		player.play();

		a=null;
	}
}

