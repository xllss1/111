package game;




import java.applet.Applet;
import java.applet.AudioClip;
import java.awt.print.Paper;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;

import go.game6;
import go.game61;
import go.game62;
import go.game63;
import go.game64;
import go.game65;
import go.print;
import javazoom.jl.decoder.JavaLayerException;


public class Stage6 {
	public static int  lang1=0;
	public static int  lang2=0;
	public static int nvwu1=0;
	public static int sheng1=0;
	int sa=0;
	int save;


    /**
     * 分配身份方法
     * @param data Data[] 游戏数据数组
     */
    public void distributionIdentity6(data6 data){
        Vector<String> copyIdentity = new Vector<String>(Arrays.asList(data.getid()));
        for(int i = 0 ; i < 6; i++){
            int randomNum = (int) (Math.random() * (6-i));
            data.getGamers()[i].setid(copyIdentity.get(randomNum));
            copyIdentity.remove(randomNum);
        }

        //分配完身份，设置data身份数据
        for(int i = 0 ; i < 6; i++){
            if(data.getGamers()[i].getid().equals("平民")) {
                data.getGamers()[i].setpeople(true);
            }
            else if(data.getGamers()[i].getid().equals("狼人")) {
                data.getGamers()[i].setpeople(false);
            }
            else if(data.getGamers()[i].getid().equals("预言家")) {
                data.setyuyanjia(i);
                data.getGamers()[i].setpeople(true);
            }
            else if(data.getGamers()[i].getid().equals("女巫")) {
                data.setnvwu(i);
                data.getGamers()[i].setjieyao(true);
                data.getGamers()[i].setduyao(true);
                data.getGamers()[i].setpeople(true);
            }
           
        }
    }

    /**
     * 晚上过程
     * @param data Data[] 游戏数据数组
     * @return 0-未结束，1-好人胜利，2-狼人胜利
     */
    public int runNight6(data6 data){

		game6.msg+="天黑请闭眼...";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        
        game61.msg+="天黑请闭眼...";
        game61.msg+="\n";
        game61.t1.setText(game6.msg);
        
        game62.msg+="天黑请闭眼...";
        game62.msg+="\n";
        game62.t1.setText(game6.msg);
        
        game63.msg+="天黑请闭眼...";
        game63.msg+="\n";
        game63.t1.setText(game6.msg);
        
        game64.msg+="天黑请闭眼...";
        game64.msg+="\n";
        game64.t1.setText(game6.msg);
        
        game65.msg+="天黑请闭眼...";
        game65.msg+="\n";
        game65.t1.setText(game6.msg);
        try {
        	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\录音-001.mp3");
			MusicPlayer.bf(null);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JavaLayerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
        //狼人回合
        
		game6.msg+="狼人请睁眼...";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        
		game61.msg+="狼人请睁眼...";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        
		game62.msg+="狼人请睁眼...";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        
		game63.msg+="狼人请睁眼...";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        
		game64.msg+="狼人请睁眼...";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        
		game65.msg+="狼人请睁眼...";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        


        int diedGamerId;
        int die=0;
        while(true){
        	if (lang1==1){
        		die = Input.inputOption(0,6,"狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：", "输入有误，请重新输入：");
        	}
        	if (lang1==2){
        		die = Input.inputOption1(0,6,"狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：", "输入有误，请重新输入：");
        	}
        	if (lang1==3){
        		die = Input.inputOption2(0,6,"狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：", "输入有误，请重新输入：");
        	}
        	if (lang1==4){
        		die = Input.inputOption3(0,6,"狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：", "输入有误，请重新输入：");
        	}
        	if (lang1==5){
        		die = Input.inputOption4(0,6,"狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：", "输入有误，请重新输入：");
        	}
        	if (lang1==6){
        		die = Input.inputOption5(0,6,"狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：", "输入有误，请重新输入：");
        	}
        	diedGamerId=die;

            
    		game6.msg+="-----+++++-----+++++-----+++++-----";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
    		game6.msg+="狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
            
    		game61.msg+="-----+++++-----+++++-----+++++-----";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
    		game61.msg+="狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
            
    		game62.msg+="-----+++++-----+++++-----+++++-----";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
    		game62.msg+="狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
            
    		game63.msg+="-----+++++-----+++++-----+++++-----";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
    		game63.msg+="狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
            
    		game64.msg+="-----+++++-----+++++-----+++++-----";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
    		game64.msg+="狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
            
    		game65.msg+="-----+++++-----+++++-----+++++-----";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
    		game65.msg+="狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            if(diedGamerId==0) {
            	break;
            }
            else {
            	diedGamerId -= 1;
                //判断玩家是否存活
                if(data.getGamers()[diedGamerId].getislive()) {
                    data.getGamers()[diedGamerId].setislive(false);
                    break;
                }
                else    		
                	
                	game6.msg+="你们选择猎杀的玩家在前面的回合中已经死亡，请重新选择！";
                    game6.msg+="\n";
                    game6.t1.setText(game6.msg);
                	
                	game61.msg+="你们选择猎杀的玩家在前面的回合中已经死亡，请重新选择！";
                    game61.msg+="\n";
                    game61.t1.setText(game61.msg);
                	
                	game62.msg+="你们选择猎杀的玩家在前面的回合中已经死亡，请重新选择！";
                    game62.msg+="\n";
                    game62.t1.setText(game62.msg);
                	
                	game63.msg+="你们选择猎杀的玩家在前面的回合中已经死亡，请重新选择！";
                    game63.msg+="\n";
                    game63.t1.setText(game63.msg);
                	
                	game64.msg+="你们选择猎杀的玩家在前面的回合中已经死亡，请重新选择！";
                    game64.msg+="\n";
                    game64.t1.setText(game64.msg);
                	
                	game65.msg+="你们选择猎杀的玩家在前面的回合中已经死亡，请重新选择！";
                    game65.msg+="\n";
                    game65.t1.setText(game65.msg);
                    

            }
            
        }

        //判断是否结束
        int res = isGamerOver6(data);
        if(res != 0){
            return res;
        }

        //预言家回合
        int seeGamerIdentityId;
        int see=0;

        if(data.getGamers()[data.getyuyanjia()].getislive() || diedGamerId == data.getyuyanjia()){
        	
        	game6.msg+="预言家请睁眼...";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	
        	game61.msg+="预言家请睁眼...";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	
        	game62.msg+="预言家请睁眼...";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	
        	game63.msg+="预言家请睁眼...";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	
        	game64.msg+="预言家请睁眼...";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	
        	game65.msg+="预言家请睁眼...";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
	        try {
	        	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\预言家.mp3");
				MusicPlayer.bf(null);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (JavaLayerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

            while(true){
            	if(sheng1==1) {
                    see = Input.inputOption(1,6,"预言家，请查看您想查看的身份：","输入有误，请重新输入：");
            	}
            	if(sheng1==2) {
                    see = Input.inputOption1(1,6,"预言家，请查看您想查看的身份：","输入有误，请重新输入：");
            	}

            	if(sheng1==3) {
                    see = Input.inputOption2(1,6,"预言家，请查看您想查看的身份：","输入有误，请重新输入：");
            	}

            	if(sheng1==4) {
                    see = Input.inputOption3(1,6,"预言家，请查看您想查看的身份：","输入有误，请重新输入：");
            	}

            	if(sheng1==5) {
                    see = Input.inputOption4(1,6,"预言家，请查看您想查看的身份：","输入有误，请重新输入：");
            	}

            	if(sheng1==6) {
                    see = Input.inputOption5(1,6,"预言家，请查看您想查看的身份：","输入有误，请重新输入：");
            	}


            	seeGamerIdentityId =see;
                seeGamerIdentityId -= 1;
                if(!data.getGamers()[seeGamerIdentityId].getislive() && diedGamerId != seeGamerIdentityId){
                	
                	game6.msg+="查看无效，您选择的人在以前的回合已死，无法查看！";
                    game6.msg+="\n";
                    game6.t1.setText(game6.msg);
                	
                	game61.msg+="查看无效，您选择的人在以前的回合已死，无法查看！";
                    game61.msg+="\n";
                    game61.t1.setText(game61.msg);
                	
                	game62.msg+="查看无效，您选择的人在以前的回合已死，无法查看！";
                    game62.msg+="\n";
                    game62.t1.setText(game62.msg);
                	
                	game63.msg+="查看无效，您选择的人在以前的回合已死，无法查看！";
                    game63.msg+="\n";
                    game63.t1.setText(game63.msg);
                	
                	game64.msg+="查看无效，您选择的人在以前的回合已死，无法查看！";
                    game64.msg+="\n";
                    game64.t1.setText(game64.msg);
                	
                	game65.msg+="查看无效，您选择的人在以前的回合已死，无法查看！";
                    game65.msg+="\n";
                    game65.t1.setText(game65.msg);

                }else break;
            }

            String seeGamerIdentity = data.getGamers()[seeGamerIdentityId].getpeople() ? "好人" : "狼人";

        	game6.msg+="预言家，您查看的人是：" + seeGamerIdentity + "！";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	game6.msg+="预言家请闭眼！";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);

        	game61.msg+="预言家，您查看的人是：" + seeGamerIdentity + "！";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	game61.msg+="预言家请闭眼！";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);

        	game62.msg+="预言家，您查看的人是：" + seeGamerIdentity + "！";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	game62.msg+="预言家请闭眼！";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);

        	game63.msg+="预言家，您查看的人是：" + seeGamerIdentity + "！";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	game63.msg+="预言家请闭眼！";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);

        	game64.msg+="预言家，您查看的人是：" + seeGamerIdentity + "！";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	game64.msg+="预言家请闭眼！";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);

        	game65.msg+="预言家，您查看的人是：" + seeGamerIdentity + "！";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
        	game65.msg+="预言家请闭眼！";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            
            

        }


        //女巫行动
    	game6.msg+="女巫请睁眼：";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        
    	game61.msg+="女巫请睁眼：";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        
    	game62.msg+="女巫请睁眼：";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        
    	game63.msg+="女巫请睁眼：";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        
    	game64.msg+="女巫请睁眼：";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        
    	game65.msg+="女巫请睁眼：";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        try {
        	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\女巫请睁眼.mp3");
			MusicPlayer.bf(null);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JavaLayerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        //女巫有解药
        boolean isSave = false;
        boolean isS = false;

        if(data.getGamers()[data.getnvwu()].getjieyao()){
        	if(diedGamerId==0) {
        		
            	game6.msg+="女巫，昨晚平安夜";
                game6.msg+="\n";
                game6.t1.setText(game6.msg);
        		
            	game61.msg+="女巫，昨晚平安夜";
                game61.msg+="\n";
                game61.t1.setText(game61.msg);
        		
            	game62.msg+="女巫，昨晚平安夜";
                game62.msg+="\n";
                game62.t1.setText(game62.msg);
        		
            	game63.msg+="女巫，昨晚平安夜";
                game63.msg+="\n";
                game63.t1.setText(game63.msg);
        		
            	game64.msg+="女巫，昨晚平安夜";
                game64.msg+="\n";
                game64.t1.setText(game64.msg);
        		
            	game65.msg+="女巫，昨晚平安夜";
                game65.msg+="\n";
                game65.t1.setText(game65.msg);
                try {
                	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\女巫，昨晚平安夜.mp3");
        			MusicPlayer.bf(null);
        		} catch (FileNotFoundException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		} catch (JavaLayerException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
                
        	}
        	else {
        		
            	game6.msg+="女巫，昨晚被杀死的人是：" + (diedGamerId + 1);
                game6.msg+="\n";
                game6.t1.setText(game6.msg);
        		
            	game61.msg+="女巫，昨晚被杀死的人是：" + (diedGamerId + 1);
                game61.msg+="\n";
                game61.t1.setText(game61.msg);
        		
            	game62.msg+="女巫，昨晚被杀死的人是：" + (diedGamerId + 1);
                game62.msg+="\n";
                game62.t1.setText(game62.msg);
        		
            	game63.msg+="女巫，昨晚被杀死的人是：" + (diedGamerId + 1);
                game63.msg+="\n";
                game63.t1.setText(game63.msg);
        		
            	game64.msg+="女巫，昨晚被杀死的人是：" + (diedGamerId + 1);
                game64.msg+="\n";
                game64.t1.setText(game64.msg);
        		
            	game65.msg+="女巫，昨晚被杀死的人是：" + (diedGamerId + 1);
                game65.msg+="\n";
                game65.t1.setText(game65.msg);

                try {
                	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\女巫、昨晚被杀死的人是.mp3");
        			MusicPlayer.bf(null);
        		} catch (FileNotFoundException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		} catch (JavaLayerException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
                if(nvwu1==1) {
                     sa = Input.inputOption(0,1,"请问您是否要救(0-不救，1-救)：","输入有误，请重新输入：");
                }
                if(nvwu1==2) {
                     sa = Input.inputOption1(0,1,"请问您是否要救(0-不救，1-救)：","输入有误，请重新输入：");
                }
                if(nvwu1==3) {
                     sa = Input.inputOption2(0,1,"请问您是否要救(0-不救，1-救)：","输入有误，请重新输入：");
                }
                if(nvwu1==4) {
                     sa = Input.inputOption3(0,1,"请问您是否要救(0-不救，1-救)：","输入有误，请重新输入：");
                }
                if(nvwu1==5) {
                     sa = Input.inputOption4(0,1,"请问您是否要救(0-不救，1-救)：","输入有误，请重新输入：");
                }
                if(nvwu1==6) {
                     sa = Input.inputOption5(0,1,"请问您是否要救(0-不救，1-救)：","输入有误，请重新输入：");
                }
                try {
                	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\请问你是否要救.mp3");
        			MusicPlayer.bf(null);
        		} catch (FileNotFoundException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		} catch (JavaLayerException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}

                 
                 save=sa;
                 if(save == 1){
                     data.getGamers()[diedGamerId].setislive(true);
                     data.getGamers()[data.getnvwu()].setjieyao(false);
                     isSave = true;
                 }
        	}
           
        }
        //女巫有毒药
        int poisonId = 0;
        if(data.getGamers()[data.getnvwu()].getduyao() && !isSave){
        	int isPoison=0;
        	if(nvwu1==1) {
            	isPoison= Input.inputOption(0,1,"请问您是否要使用毒药(0-不使用，1-使用)：","输入有误，请重新输入：");
        	}
        	if(nvwu1==2) {
            	isPoison= Input.inputOption1(0,1,"请问您是否要使用毒药(0-不使用，1-使用)：","输入有误，请重新输入：");
        	}
        	if(nvwu1==3) {
            	isPoison= Input.inputOption2(0,1,"请问您是否要使用毒药(0-不使用，1-使用)：","输入有误，请重新输入：");
        	}
        	if(nvwu1==4) {
            	isPoison= Input.inputOption3(0,1,"请问您是否要使用毒药(0-不使用，1-使用)：","输入有误，请重新输入：");
        	}
        	if(nvwu1==5) {
            	isPoison= Input.inputOption4(0,1,"请问您是否要使用毒药(0-不使用，1-使用)：","输入有误，请重新输入：");
        	}
        	if(nvwu1==6) {
            	isPoison= Input.inputOption5(0,1,"请问您是否要使用毒药(0-不使用，1-使用)：","输入有误，请重新输入：");
        	}
            try {
            	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\请问你是否使用毒药.mp3");
    			MusicPlayer.bf(null);
    		} catch (FileNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (JavaLayerException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
            if(isPoison == 1){
                while(true){
                	if(nvwu1==1) {
                		poisonId = Input.inputOption(1,6, "请选择您要毒死的玩家：", "输入有误，请重新输入：");
                	}
                	if(nvwu1==2) {
                		poisonId = Input.inputOption1(1,6, "请选择您要毒死的玩家：", "输入有误，请重新输入：");
                	}
                	if(nvwu1==3) {
                		poisonId = Input.inputOption2(1,6, "请选择您要毒死的玩家：", "输入有误，请重新输入：");
                	}
                	if(nvwu1==4) {
                		poisonId = Input.inputOption3(1,6, "请选择您要毒死的玩家：", "输入有误，请重新输入：");
                	}
                	if(nvwu1==5) {
                		poisonId = Input.inputOption4(1,6, "请选择您要毒死的玩家：", "输入有误，请重新输入：");
                	}
                	if(nvwu1==6) {
                		poisonId = Input.inputOption5(1,6, "请选择您要毒死的玩家：", "输入有误，请重新输入：");
                	}
                    
                    if(!data.getGamers()[poisonId-1].getislive()){
                    	
                    	game6.msg+="您选择的人已经死了，请重新选择：";
                        game6.msg+="\n";
                        game6.t1.setText(game6.msg);
                    	
                    	game61.msg+="您选择的人已经死了，请重新选择：";
                        game61.msg+="\n";
                        game61.t1.setText(game61.msg);
                    	
                    	game62.msg+="您选择的人已经死了，请重新选择：";
                        game62.msg+="\n";
                        game62.t1.setText(game62.msg);
                    	
                    	game63.msg+="您选择的人已经死了，请重新选择：";
                        game63.msg+="\n";
                        game63.t1.setText(game63.msg);
                    	
                    	game64.msg+="您选择的人已经死了，请重新选择：";
                        game64.msg+="\n";
                        game64.t1.setText(game64.msg);
                    	
                    	game65.msg+="您选择的人已经死了，请重新选择：";
                        game65.msg+="\n";
                        game65.t1.setText(game65.msg);
                    }else {
                        data.getGamers()[data.getnvwu()].setjieyao(false);
                        data.getGamers()[poisonId-1].setislive(false);
                        break;
                    }
                }
            }
            

            
            //判断是否结束
            res = isGamerOver6(data);
            if(res != 0){
                return res;
            }
        }

        //宣布死讯
        
        game6.msg+="白天，大家请睁眼！";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        
        game61.msg+="白天，大家请睁眼！";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        
        game62.msg+="白天，大家请睁眼！";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        
        game63.msg+="白天，大家请睁眼！";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        
        game64.msg+="白天，大家请睁眼！";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        
        game65.msg+="白天，大家请睁眼！";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        try {
        	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\白天，大家请睁眼.mp3");
			MusicPlayer.bf(null);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JavaLayerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        if(isSave){
        	
            game6.msg+="昨晚是个平安夜~";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	
            game61.msg+="昨晚是个平安夜~";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	
            game62.msg+="昨晚是个平安夜~";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	
            game63.msg+="昨晚是个平安夜~";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	
            game64.msg+="昨晚是个平安夜~";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	
            game65.msg+="昨晚是个平安夜~";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            try {
            	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\昨晚是个平安夜.mp3");
    			MusicPlayer.bf(null);
    		} catch (FileNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (JavaLayerException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

        }else if(diedGamerId==0) {
        	
            game6.msg+="昨晚是个平安夜~";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	
            game61.msg+="昨晚是个平安夜~";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	
            game62.msg+="昨晚是个平安夜~";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	
            game63.msg+="昨晚是个平安夜~";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	
            game64.msg+="昨晚是个平安夜~";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	
            game65.msg+="昨晚是个平安夜~";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            try {
            	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\昨晚是个平安夜.mp3");
    			MusicPlayer.bf(null);
    		} catch (FileNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (JavaLayerException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

        }
        else if(poisonId != 0){
        	
            game6.msg+="昨晚死亡的人是：" + (diedGamerId + 1) + "号和" + (poisonId) + "号玩家！";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	
            game61.msg+="昨晚死亡的人是：" + (diedGamerId + 1) + "号和" + (poisonId) + "号玩家！";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	
            game62.msg+="昨晚死亡的人是：" + (diedGamerId + 1) + "号和" + (poisonId) + "号玩家！";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	
            game63.msg+="昨晚死亡的人是：" + (diedGamerId + 1) + "号和" + (poisonId) + "号玩家！";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	
            game64.msg+="昨晚死亡的人是：" + (diedGamerId + 1) + "号和" + (poisonId) + "号玩家！";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	
            game65.msg+="昨晚死亡的人是：" + (diedGamerId + 1) + "号和" + (poisonId) + "号玩家！";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            try {
            	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\昨晚死亡的人是.mp3");
    			MusicPlayer.bf(null);
    		} catch (FileNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (JavaLayerException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}


        }else{
        	
            game6.msg+="昨晚死亡的人是" + (diedGamerId + 1) + "号玩家！";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	
            game61.msg+="昨晚死亡的人是" + (diedGamerId + 1) + "号玩家！";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	
            game62.msg+="昨晚死亡的人是" + (diedGamerId + 1) + "号玩家！";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	
            game63.msg+="昨晚死亡的人是" + (diedGamerId + 1) + "号玩家！";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	
            game64.msg+="昨晚死亡的人是" + (diedGamerId + 1) + "号玩家！";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	
            game65.msg+="昨晚死亡的人是" + (diedGamerId + 1) + "号玩家！";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            try {
            	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\昨晚死亡的人是.mp3");
    			MusicPlayer.bf(null);
    		} catch (FileNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (JavaLayerException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

        }


        //如果死亡的是猎人
     
        return 0;
    }

    /**
     * 白天过程
     * @param data Data[] 游戏数据数组
     * @return 0-未结束，1-好人胜利，2-狼人胜利
     */
    public int runDaytime6(data6 data){
        //活着的人存入
        Vector<Integer> liveGamers = new Vector<Integer>();
        for(int i = 0 ; i < 6; i++){
            if(data.getGamers()[i].getislive()){
                liveGamers.add(i);
            }
        }
        //随机指定人发言
        for(int i = liveGamers.size(); i > 0; i--){
            int talkGamerId = (int) (Math.random() * i);
            
            game6.msg+="请" + (liveGamers.get(talkGamerId)+ 1) + "号玩家发言：";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
            
            game61.msg+="请" + (liveGamers.get(talkGamerId)+ 1) + "号玩家发言：";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
            
            game62.msg+="请" + (liveGamers.get(talkGamerId)+ 1) + "号玩家发言：";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
            
            game63.msg+="请" + (liveGamers.get(talkGamerId)+ 1) + "号玩家发言：";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
            
            game64.msg+="请" + (liveGamers.get(talkGamerId)+ 1) + "号玩家发言：";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
            
            game65.msg+="请" + (liveGamers.get(talkGamerId)+ 1) + "号玩家发言：";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);

            liveGamers.remove(talkGamerId);
            
        }


        //投票
        int diedOutId = -1;
        while(true){
            diedOutId = Input.inputOption(0,6,"请大家商讨，输入0则为弃权，决定要票出的玩家：","输入有误，请重新输入：");
            if(diedOutId==0) {
            	
                game6.msg+="今晚是平安夜！";
                game6.msg+="\n";
                game6.t1.setText(game6.msg);
            	
                game61.msg+="今晚是平安夜！";
                game61.msg+="\n";
                game61.t1.setText(game61.msg);
            	
                game62.msg+="今晚是平安夜！";
                game62.msg+="\n";
                game62.t1.setText(game62.msg);
            	
                game63.msg+="今晚是平安夜！";
                game63.msg+="\n";
                game63.t1.setText(game63.msg);
            	
                game64.msg+="今晚是平安夜！";
                game64.msg+="\n";
                game64.t1.setText(game64.msg);
            	
                game65.msg+="今晚是平安夜！";
                game65.msg+="\n";
                game65.t1.setText(game65.msg);

            }
            else {
            	 diedOutId -= 1;
                 if(!data.getGamers()[diedOutId].getislive()){
                	 
                     game6.msg+="该玩家以前的回合已经死了，请重新决定！";
                     game6.msg+="\n";
                     game6.t1.setText(game6.msg);
                	 
                     game61.msg+="该玩家以前的回合已经死了，请重新决定！";
                     game61.msg+="\n";
                     game61.t1.setText(game61.msg);
                	 
                     game62.msg+="该玩家以前的回合已经死了，请重新决定！";
                     game62.msg+="\n";
                     game62.t1.setText(game62.msg);
                	 
                     game63.msg+="该玩家以前的回合已经死了，请重新决定！";
                     game63.msg+="\n";
                     game63.t1.setText(game63.msg);
                	 
                     game64.msg+="该玩家以前的回合已经死了，请重新决定！";
                     game64.msg+="\n";
                     game64.t1.setText(game64.msg);
                	 
                     game65.msg+="该玩家以前的回合已经死了，请重新决定！";
                     game65.msg+="\n";
                     game65.t1.setText(game65.msg);

                     continue;
                 }
            }
            break;
        }
        if(diedOutId!=0) {
        	
            game6.msg+="你们票出的玩家是：" + (diedOutId + 1);
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	
            game61.msg+="你们票出的玩家是：" + (diedOutId + 1);
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	
            game62.msg+="你们票出的玩家是：" + (diedOutId + 1);
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	
            game63.msg+="你们票出的玩家是：" + (diedOutId + 1);
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	
            game64.msg+="你们票出的玩家是：" + (diedOutId + 1);
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	
            game65.msg+="你们票出的玩家是：" + (diedOutId + 1);
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            try {
            	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\你们票出的玩家是.mp3");
    			MusicPlayer.bf(null);
    		} catch (FileNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (JavaLayerException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

        }


        data.getGamers()[diedOutId].setislive(false);
        //判断是否结束
        int res = isGamerOver6(data);
        if(res != 0){
            return res;
        }

        //票出的玩家是猎人：
        

        //票出的玩家是白痴：
     
        //判断是否结束
        
        else return 0;
    }

    /**
     * 判断游戏是否结束
     * @param data Data[] 游戏数据数组
     * @return int 0-未结束，1-好人胜利，2-狼人胜利
     */
    public int isGamerOver6(data6 data){
        //判断游戏是否结束了
    	int personNum = 0, wolfNum = 0;
        for(int i = 0 ; i < 6; i++){
            if(data.getGamers()[i].getislive()){
                if(data.getGamers()[i].getid().equals("狼人")) wolfNum++;
                else if(data.getGamers()[i].getid().equals("平民")||data.getGamers()[i].getid().equals("女巫")||data.getGamers()[i].getid().equals("预言家")) personNum++;
//                else godNum++;
            }
        }

        if(wolfNum == 0) return 1;
        else if(personNum == 1) return 2;
//        else if(godNum == 0) return 2;
        else return 0;
    }

    /**
     * 游戏阶段
     * @param data Data[] 游戏数据数组
     */
    public void gaming6(data6 data){
        int res;
        while (true){
           res = runNight6(data);
           if(res != 0) break;
            res = runDaytime6(data);
            if(res != 0) break;
        }
        theGameOver(res);
    }

    /**
     * 游戏结束阶段
     * @param res int 最后胜利结果
     */
    public void theGameOver(int res){
        if(res == 1){
        	
         game6.msg+="游戏结束，好人胜利";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	
         game61.msg+="游戏结束，好人胜利";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	
         game62.msg+="游戏结束，好人胜利";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	
         game63.msg+="游戏结束，好人胜利";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	
         game64.msg+="游戏结束，好人胜利";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	
         game65.msg+="游戏结束，好人胜利";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
           
            
        }else if(res == 2){
        	
         game6.msg+="游戏结束，狼人胜利";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
        	
         game61.msg+="游戏结束，狼人胜利";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
        	
         game62.msg+="游戏结束，狼人胜利";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
        	
         game63.msg+="游戏结束，狼人胜利";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
        	
         game64.msg+="游戏结束，狼人胜利";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
        	
         game65.msg+="游戏结束，狼人胜利";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            try {
            	MusicPlayer.a=("C:\\\\Users\\\\13592\\\\Desktop\\\\策划部会议纪要\\\\狼人杀里.mp3");
    			MusicPlayer.bf(null);
    		} catch (FileNotFoundException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		} catch (JavaLayerException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

            
        }
        
        game6.msg+="欢迎下次继续玩耍~~~";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        game6.msg+="正在退出";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        print.printDot(3);
        
        game61.msg+="欢迎下次继续玩耍~~~";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        game61.msg+="正在退出";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        print.printDot(3);
        
        game62.msg+="欢迎下次继续玩耍~~~";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        game62.msg+="正在退出";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        print.printDot(3);
        
        game63.msg+="欢迎下次继续玩耍~~~";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        game63.msg+="正在退出";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        print.printDot(3);
        
        game64.msg+="欢迎下次继续玩耍~~~";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        game64.msg+="正在退出";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        print.printDot(3);
        
        game65.msg+="欢迎下次继续玩耍~~~";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        game65.msg+="正在退出";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        print.printDot(3);
    }
}

