package game;

import java.util.Scanner;

public class main {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	            	data6 data =  new data6();
	                menu6 menu = new menu6();       
	                Stage6 stage = new Stage6();
	                menu.welcome6(data,stage);

            	

            		
            		
	                
	         
	            
	        }
	        
}
