package game;




import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;

import go.game12;
import go.game12;
import go.print;


public class Stage {


    /**
     * 分配身份方法
     * @param data Data[] 游戏数据数组
     */
    public void distributionIdentity(data data){
        Vector<String> copyIdentity = new Vector<String>(Arrays.asList(data.getid()));
        for(int i = 0 ; i < 12; i++){
            int randomNum = (int) (Math.random() * (12-i));
            data.getGamers()[i].setid(copyIdentity.get(randomNum));
            copyIdentity.remove(randomNum);
        }

        //分配完身份，设置data身份数据
        for(int i = 0 ; i < 12; i++){
            if(data.getGamers()[i].getid().equals("平民")) {
                data.getGamers()[i].setpeople(true);
            }
            else if(data.getGamers()[i].getid().equals("狼人")) {
                data.getGamers()[i].setpeople(false);
            }
            else if(data.getGamers()[i].getid().equals("预言家")) {
                data.setyuyanjia(i);
                data.getGamers()[i].setpeople(true);
            }
            else if(data.getGamers()[i].getid().equals("女巫")) {
                data.setnvwu(i);
                data.getGamers()[i].setjieyao(true);
                data.getGamers()[i].setduyao(true);
                data.getGamers()[i].setpeople(true);
            }
            else if(data.getGamers()[i].getid().equals("猎人")) {
                data.setlieren(i);
                data.getGamers()[i].setpeople(true);
            }
            else if(data.getGamers()[i].getid().equals("白痴")) {
                data.setbaichi(i);
                data.getGamers()[i].setbusi(true);
                data.getGamers()[i].setpeople(true);
            }
        }
    }

    /**
     * 晚上过程
     * @param data Data[] 游戏数据数组
     * @return 0-未结束，1-好人胜利，2-狼人胜利
     */
    public int runNight(data data){
		game12.msg+="天黑请闭眼...";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);


        //狼人回合
		game12.msg+="狼人请睁眼...";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        int diedGamerId;
        while(true){
        	  diedGamerId = Input.inputOption(0,6,"狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：", "输入有误，请重新输入：");
      		game12.msg+="-----+++++-----+++++-----+++++-----";
              game12.msg+="\n";
              game12.t1.setText(game12.msg);
      		game12.msg+="狼人，输入0则放弃杀人，请你们选择你们即将猎杀的玩家：";
              game12.msg+="\n";
              game12.t1.setText(game12.msg);
            //判断玩家是否存活
            if(data.getGamers()[diedGamerId].getislive()) {
                data.getGamers()[diedGamerId].setislive(false);
                break;
            }
            else                 	
            game12.msg+="你们选择猎杀的玩家在前面的回合中已经死亡，请重新选择！";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);
        }

        //判断是否结束
        int res = isGamerOver(data);
        if(res != 0){
            return res;
        }

        //预言家回合
        int seeGamerIdentityId;
        if(data.getGamers()[data.getyuyanjia()].getislive() || diedGamerId == data.getyuyanjia()){
        	game12.msg+="预言家请睁眼...";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);

            while(true){
                seeGamerIdentityId = Input.inputOption(1,12,"预言家，请查看您想查看的身份：","输入有误，请重新输入：");
                seeGamerIdentityId -= 1;
                if(!data.getGamers()[seeGamerIdentityId].getislive() && diedGamerId != seeGamerIdentityId){
                	game12.msg+="查看无效，您选择的人在以前的回合已死，无法查看！";
                    game12.msg+="\n";
                    game12.t1.setText(game12.msg);
                }else break;
            }

            String seeGamerIdentity = data.getGamers()[seeGamerIdentityId].getpeople() ? "好人" : "狼人";

        	game12.msg+="预言家，您查看的人是：" + seeGamerIdentity + "！";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);
        	game12.msg+="预言家请闭眼！";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);
        }


        //女巫行动
    	game12.msg+="女巫请睁眼：";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);

        //女巫有解药
        boolean isSave = false;
        if(data.getGamers()[data.getnvwu()].getjieyao()){
        	game12.msg+="女巫，昨晚被杀死的人是：" + (diedGamerId + 1);
            game12.msg+="\n";
            game12.t1.setText(game12.msg);

            int save = Input.inputOption(0,1,"请问您是否要救(0-不救，1-救)：","输入有误，请重新输入：");
            if(save == 1){
                data.getGamers()[diedGamerId].setislive(true);
                data.getGamers()[data.getnvwu()].setjieyao(false);
                isSave = true;
            }
        }
        //女巫有毒药
        int poisonId = 0;
        if(data.getGamers()[data.getnvwu()].getduyao() && !isSave){
            int isPoison = Input.inputOption(0,1,"请问您是否要使用毒药(0-不使用，1-使用)：","输入有误，请重新输入：");
            if(isPoison == 1){
                while(true){
                    poisonId = Input.inputOption(1,12, "请选择您要毒死的玩家：", "输入有误，请重新输入：");
                    if(!data.getGamers()[poisonId].getislive()){
                    	game12.msg+="您选择的人已经死了，请重新选择：";
                        game12.msg+="\n";
                        game12.t1.setText(game12.msg);
                    }else {
                        data.getGamers()[data.getnvwu()].setjieyao(false);
                        break;
                    }
                }
            }


            data.getGamers()[poisonId].setislive(false);
            //判断是否结束
            res = isGamerOver(data);
            if(res != 0){
                return res;
            }
        }

        //宣布死讯
        
    	game12.msg+="白天，大家请睁眼！";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        if(isSave){
        	game12.msg+="昨晚是个平安夜~";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);
        }else if(poisonId != 0){
        	game12.msg+="昨晚死亡的人是：" + (diedGamerId + 1) + "号和" + (poisonId) + "号玩家！";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);

        }else{
        	game12.msg+="昨晚死亡的人是" + (diedGamerId + 1) + "号玩家！";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);

        }


        //如果死亡的是猎人
        int huntId = 0;
        if(!isSave && (poisonId == data.getlieren() || diedGamerId == data.getlieren())){
            int isUseSkill = Input.inputOption(0,1,"猎人，昨晚您死亡了，请问，您是否发动技能开枪带走一名玩家(0-否，1-是)：","输入有误，请重新输入：");
            if(isUseSkill == 1){
                while(true){
                    huntId = Input.inputOption(1,12, "请选择您要猎杀的玩家：", "输入有误，请重新输入：");

                    if(!data.getGamers()[huntId].getislive()){
                    	game12.msg+="您选择的人已经死了，请重新选择：";
                        game12.msg+="\n";
                        game12.t1.setText(game12.msg);
                    }else break;
                }
            }
            data.getGamers()[huntId-1].setislive(false);
        	game12.msg+="猎人杀死了" + (huntId) + "号玩家！";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);
            //判断是否结束
            res = isGamerOver(data);
            if(res != 0){
                return res;
            }
        }
        return 0;
    }

    /**
     * 白天过程
     * @param data Data[] 游戏数据数组
     * @return 0-未结束，1-好人胜利，2-狼人胜利
     */
    public int runDaytime(data data){
        //活着的人存入
        Vector<Integer> liveGamers = new Vector<Integer>();
        for(int i = 0 ; i < 12; i++){
            if(data.getGamers()[i].getislive()){
                liveGamers.add(i);
            }
        }
        //随机指定人发言
        for(int i = liveGamers.size(); i > 0; i--){
            int talkGamerId = (int) (Math.random() * i);
        	game12.msg+="请" + (liveGamers.get(talkGamerId)+ 1) + "号玩家发言：";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);
            liveGamers.remove(talkGamerId);
        }


        //投票
        int diedOutId = -1;
        while(true){
            diedOutId = Input.inputOption(0,12,"请大家商讨，输入0，即为弃权，决定要票出的玩家：","输入有误，请重新输入：");
            if(diedOutId==0) {
            	game12.msg+="平安夜";
                game12.msg+="\n";
                game12.t1.setText(game12.msg);
            
            }
            else {
            	diedOutId -= 1;
            	if(!data.getGamers()[diedOutId].getislive()){
                	game12.msg+="该玩家以前的回合已经死了，请重新决定！";
                    game12.msg+="\n";
                    game12.t1.setText(game12.msg);
                    continue;
            }
            }      
            break;
        }
        if(diedOutId!=0) {
        	game12.msg+="你们票出的玩家是：" + (diedOutId + 1);
            game12.msg+="\n";
            game12.t1.setText(game12.msg);

        }
        data.getGamers()[diedOutId].setislive(false);
        //判断是否结束
        int res = isGamerOver(data);
        if(res != 0){
            return res;
        }

        //票出的玩家是猎人：
        int huntId = -1;
        if(data.getGamers()[diedOutId].getid().equals("猎人")) {
            int isUseSkill = Input.inputOption(0, 1, "猎人，您被各位玩家票出，请问，您是否发动技能开枪带走一名玩家(0-否，1-是)：", "输入有误，请重新输入：");
            if (isUseSkill == 1) {
                while (true) {
                    huntId = Input.inputOption(1, 12, "请选择您要猎杀的玩家：", "输入有误，请重新输入：");
                    huntId -= 1;
                    if (!data.getGamers()[huntId].getislive()) {
                    	game12.msg+="您选择的人已经死了，请重新选择：";
                        game12.msg+="\n";
                        game12.t1.setText(game12.msg);
                    } else break;
                }
            }
            data.getGamers()[huntId].setislive(false);
            //判断是否结束
            res = isGamerOver(data);
            if(res != 0){
                return res;
            }
        }

        //票出的玩家是白痴：
        if(data.getGamers()[diedOutId].getid().equals("白痴")){
            if(data.getGamers()[data.getbaichi()].getbusi()){
                int isUseSkill = Input.inputOption(0, 1, "白痴，您被各位玩家票出，请问，您是否发动技能保证自己活下来(0-否，1-是)：", "输入有误，请重新输入：");
                if(isUseSkill == 1){
                	game12.msg+="白痴发动技能生效，免除公投一次";
                    game12.msg+="\n";
                    game12.t1.setText(game12.msg);
                }else
                    data.getGamers()[diedOutId].setislive(false);
            }
        }
        //判断是否结束
        res = isGamerOver(data);
        if(res != 0){
            return res;
        }
        else return 0;
    }

    /**
     * 判断游戏是否结束
     * @param data Data[] 游戏数据数组
     * @return int 0-未结束，1-好人胜利，2-狼人胜利
     */
    public int isGamerOver(data data){
    	 //判断游戏是否结束了
        int personNum = 0, wolfNum = 0;
        for(int i = 0 ; i < 9; i++){
            if(data.getGamers()[i].getislive()){
                if(data.getGamers()[i].getid().equals("狼人")) wolfNum++;
                else if(data.getGamers()[i].getid().equals("平民")||data.getGamers()[i].getid().equals("女巫")||data.getGamers()[i].getid().equals("预言家")||data.getGamers()[i].getid().equals("猎人")||data.getGamers()[i].getid().equals("白痴")) personNum++;
                
            }
        }

        if(wolfNum == 0) return 1;
        else if(personNum == 1) return 2;
    
        else return 0;
    }

    /**
     * 游戏阶段
     * @param data Data[] 游戏数据数组
     */
    public void gaming(data data){
        int res;
        while (true){
           res = runNight(data);
           if(res != 0) break;
            res = runDaytime(data);
            if(res != 0) break;
        }
        theGameOver(res);
    }

    /**
     * 游戏结束阶段
     * @param res int 最后胜利结果
     */
    public void theGameOver(int res){
        if(res == 1){
        	game12.msg+="游戏结束，好人胜利";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);

        }else if(res == 2){
        	game12.msg+="游戏结束，狼人胜利";
            game12.msg+="\n";
            game12.t1.setText(game12.msg);
        }
    	game12.msg+="欢饮下次继续玩耍~~~";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
    	game12.msg+="正在退出";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        print.printDot(3);
    }
}

