package game;

import java.util.Scanner;

import go.game6;
import go.game61;
import go.game62;
import go.game63;
import go.game64;
import go.game65;
import go.print;
import go.print6;

public class menu6 {


    public  void welcome6(data6 data,Stage6 stage){
        game6.msg+="正在进入游戏中";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        game6.msg+="欢迎您进入狼人杀游戏，祝你游戏愉快...";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        game6.msg+="-----+++++-----+++++-----+++++-----";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        game6.msg+="1.开始游戏";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        game6.msg+="2.退出游戏";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        
        game61.msg+="正在进入游戏中";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        game61.msg+="欢迎您进入狼人杀游戏，祝你游戏愉快...";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        game61.msg+="-----+++++-----+++++-----+++++-----";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        game61.msg+="1.开始游戏";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        game61.msg+="2.退出游戏";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        
        game62.msg+="正在进入游戏中";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        game62.msg+="欢迎您进入狼人杀游戏，祝你游戏愉快...";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        game62.msg+="-----+++++-----+++++-----+++++-----";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        game62.msg+="1.开始游戏";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        game62.msg+="2.退出游戏";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        
        game65.msg+="正在进入游戏中";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        game65.msg+="欢迎您进入狼人杀游戏，祝你游戏愉快...";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        game65.msg+="-----+++++-----+++++-----+++++-----";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        game65.msg+="1.开始游戏";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        game65.msg+="2.退出游戏";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        
        game63.msg+="正在进入游戏中";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        game63.msg+="欢迎您进入狼人杀游戏，祝你游戏愉快...";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        game63.msg+="-----+++++-----+++++-----+++++-----";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        game63.msg+="1.开始游戏";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        game63.msg+="2.退出游戏";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        
        game64.msg+="正在进入游戏中";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        game64.msg+="欢迎您进入狼人杀游戏，祝你游戏愉快...";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        game64.msg+="-----+++++-----+++++-----+++++-----";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        game64.msg+="1.开始游戏";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        game64.msg+="2.退出游戏";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);


        int option = game.Input.inputOption(1,2,"请输入您的选择：", "对不起，您的选择有误！");
        if(option == 1){

            kaishi6(data,stage);

        }else if(option == 2) {
            jieshu();
        }
    }
 

    public void kaishi6(data6 data,Stage6 stage){
    	game6.msg+="游戏开始了！！！";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
    	game6.msg+="请大家准备好~~~~！！！";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
    	game6.msg+="分配角色中";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        stage.distributionIdentity6(data);
        print.printDot(3);
    	game6.msg+="分配角色完毕...";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
        print6.printIdentity6(data);
        stage.gaming6(data);
        
        game61.msg+="游戏开始了！！！";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
    	game61.msg+="请大家准备好~~~~！！！";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
    	game61.msg+="分配角色中";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        stage.distributionIdentity6(data);
        print.printDot(3);
    	game61.msg+="分配角色完毕...";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
        print6.printIdentity6(data);
        stage.gaming6(data);
        
        game62.msg+="游戏开始了！！！";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
    	game62.msg+="请大家准备好~~~~！！！";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
    	game62.msg+="分配角色中";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        stage.distributionIdentity6(data);
        print.printDot(3);
    	game62.msg+="分配角色完毕...";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
        print6.printIdentity6(data);
        stage.gaming6(data);
        
        game63.msg+="游戏开始了！！！";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
    	game63.msg+="请大家准备好~~~~！！！";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
    	game63.msg+="分配角色中";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        stage.distributionIdentity6(data);
        print.printDot(3);
    	game63.msg+="分配角色完毕...";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
        print6.printIdentity6(data);
        stage.gaming6(data);
        
        game64.msg+="游戏开始了！！！";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
    	game64.msg+="请大家准备好~~~~！！！";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
    	game64.msg+="分配角色中";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        stage.distributionIdentity6(data);
        print.printDot(3);
    	game64.msg+="分配角色完毕...";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
        print6.printIdentity6(data);
        stage.gaming6(data);
        
        game65.msg+="游戏开始了！！！";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
    	game65.msg+="请大家准备好~~~~！！！";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
    	game65.msg+="分配角色中";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        stage.distributionIdentity6(data);
        print.printDot(3);
    	game65.msg+="分配角色完毕...";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        print6.printIdentity6(data);
        stage.gaming6(data);
        
        
    }


    private void jieshu() {
        game6.t1.setText("正在退出");
        game61.t1.setText("正在退出");
        game62.t1.setText("正在退出");
        game63.t1.setText("正在退出");
        game64.t1.setText("正在退出");
        game65.t1.setText("正在退出");
        print.printDot(3);
    }
}