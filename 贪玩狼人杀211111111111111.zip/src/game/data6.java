package game;

public class data6 {
    private final String[] idis = {"平民","平民","预言家","女巫","狼人","狼人"};//6种身份种类
    private final Gamer[] gamers;//玩家
    private int yuyanjia;//预言家
    private int nvwu;//女巫


    public data6(){
        this.gamers = new Gamer[6];
        for(int i = 0; i < gamers.length; i++){
            gamers[i] = new Gamer();
        }
    }

    /**
     * 获取身份
     */
    public String[] getid() {
        return idis;
    }

    /**
     * 获取游戏玩家数组
     */
    public Gamer[] getGamers() {
        return gamers;
    }

    /**
     * 获取身份id
     */
    public int getyuyanjia() {
        return yuyanjia;
    }


    public int getnvwu() {
        return nvwu;
    }


 
    public void setyuyanjia(int yuyanjiaid) {
        this.yuyanjia = yuyanjiaid;
    }


    public void setnvwu(int nvwuid) {
        this.nvwu = nvwuid;
    }




}