package game;

import go.game6;

public class LRVThread extends Thread {
	public void run() {
		int a;
		while (true) {
			
			a = Integer.parseInt(game6.shu);
			if (a == -1) {
				System.out.println("123123");
				System.out.println("cxsr");
			} else
				break;
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
