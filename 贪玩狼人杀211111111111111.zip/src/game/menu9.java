package game;

import java.util.Scanner;

import go.game6;
import go.game9;
import go.print;
import go.print9;

public class menu9 {

    public  void welcome9(data9 data,Stage9 stage){
        game9.msg+="正在进入游戏中";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
        game9.msg+="欢迎您进入狼人杀游戏，祝你游戏愉快...";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
        game9.msg+="-----+++++-----+++++-----+++++-----";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
        game9.msg+="1.开始游戏";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
        game9.msg+="2.退出游戏";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
        int option = Input.inputOption(1,2,"请输入您的选择：", "对不起，您的选择有误！");
        if(option == 1){
            kaishi9(data,stage);
        }else if(option == 2) {
            jieshu();
        }
    }
 

    public void kaishi9(data9 data,Stage9 stage){
    	game9.msg+="游戏开始了！！！";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
    	game9.msg+="请大家准备好~~~~！！！";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
    	game9.msg+="分配角色中";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
        stage.distributionIdentity9(data);
        print.printDot(3);
    	game9.msg+="分配角色完毕...";
        game9.msg+="\n";
        game9.t1.setText(game9.msg);
        print9.printIdentity9(data);
        stage.gaming9(data);
    }


    private void jieshu() {
        System.out.println("正在退出");
        print.printDot(3);
    }
}