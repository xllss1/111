package game;

public class data9 {
    private final String[] idis = {"平民","平民","平民","预言家","女巫","猎人","狼人","狼人","狼人"};//6种身份种类
    private final Gamer[] gamers;//玩家
    private int yuyanjia;//预言家
    private int nvwu;//女巫
    private int lieren;//猎人

    public data9(){
        this.gamers = new Gamer[9];
        for(int i = 0; i < gamers.length; i++){
            gamers[i] = new Gamer();
        }
    }

    public String[] getid() {
        return idis;
    }

    /**
     * 获取游戏玩家数组
     */
    public Gamer[] getGamers() {
        return gamers;
    }

    /**
     * 获取身份id
     */
    public int getyuyanjia() {
        return yuyanjia;
    }


    public int getnvwu() {
        return nvwu;
    }


    public int getlieren() {
        return lieren;
    }


    
 
    public void setyuyanjia(int yuyanjiaid) {
        this.yuyanjia = yuyanjiaid;
    }


    public void setnvwu(int nvwuid) {
        this.nvwu = nvwuid;
    }


    public void setlieren(int lierenid) {
        this.lieren = lierenid;
    }


    

}