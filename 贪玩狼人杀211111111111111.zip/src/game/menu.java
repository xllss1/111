package game;

import java.util.Scanner;

import go.game12;
import go.print;

public class menu {
	

    public void welcome(data data,Stage stage){
    	
        game12.msg+="正在进入游戏中";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        game12.msg+="欢迎您进入狼人杀游戏，祝你游戏愉快...";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        game12.msg+="-----+++++-----+++++-----+++++-----";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        game12.msg+="1.开始游戏";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        game12.msg+="2.退出游戏";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        int option = Input.inputOption(1,2,"请输入您的选择：", "对不起，您的选择有误！");
        if(option == 1){
            kaishi(data,stage);
        }else if(option == 2) {
            jieshu();
        }
    }
 

    public void kaishi(data data,Stage stage){
    	game12.msg+="游戏开始了！！！";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
    	game12.msg+="请大家准备好~~~~！！！";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
    	game12.msg+="分配角色中";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        stage.distributionIdentity(data);
        print.printDot(3);
    	game12.msg+="分配角色完毕...";
        game12.msg+="\n";
        game12.t1.setText(game12.msg);
        print.printIdentity(data);
        stage.gaming(data);
    }


    private void jieshu() {
        System.out.println("正在退出");
        print.printDot(3);
    }
}