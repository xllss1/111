package game;

import java.applet.Applet;
import java.applet.AudioClip;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JFrame;

public class asd extends JFrame{
	public static void main(String args[]) {
		bf();
	}
	public static void bf(){
		try { 
			URL cb;
			File f = new File("C:\\Users\\13592\\Desktop\\策划部会议纪要\\12月29日 下午5点21分.wma"); //引号里面的是音乐文件所在的绝对路径
			cb=f.toURL();
			AudioClip aau;
			aau = Applet.newAudioClip(cb);//加载音频
			aau.play(); //播放音频
			asd frame=new asd();
			} catch (MalformedURLException e) {
					e.printStackTrace();
			}
	}
}