package go;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.TextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class zhuc extends JFrame {

	private JPanel contentPane;
	private JPasswordField t2;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					zhuc frame = new zhuc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public zhuc() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 596, 415);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(186, 85, 211));
		contentPane.setForeground(Color.YELLOW);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel p1 = new JLabel("账号");
		p1.setFont(new Font("宋体", Font.BOLD, 20));
		p1.setBounds(96, 95, 72, 18);
		contentPane.add(p1);

		JLabel lblNewLabel_1 = new JLabel("密码");
		lblNewLabel_1.setFont(new Font("宋体", Font.BOLD, 20));
		lblNewLabel_1.setBounds(96, 160, 72, 18);
		contentPane.add(lblNewLabel_1);
		
		TextField t1 = new TextField();
		t1.setBounds(216, 95, 221, 25);
		contentPane.add(t1);
		
		t2 = new JPasswordField();
		t2.setBounds(216, 159, 221, 24);
		contentPane.add(t2);
		
		JButton btnNewButton = new JButton("登录");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		btnNewButton.setBounds(322, 268, 113, 27);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("注册");
		btnNewButton_1.setBounds(96, 268, 113, 27);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("确认密码");
		lblNewLabel_1_1.setFont(new Font("宋体", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(96, 213, 139, 18);
		contentPane.add(lblNewLabel_1_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(216, 212, 221, 24);
		contentPane.add(passwordField);
	}
}
