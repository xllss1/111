package go;

import game.data;

public class print {

    public static void printDot(int number){
        for(int i = 0 ; i < number; i++){
            try{
                Thread.sleep(300);
            }catch (InterruptedException e){
                System.out.println("游戏异常，正在退出...");
                System.exit(0);
            }
        }
        System.out.println();
    }
    
    public static void printIdentity(data data){
        System.out.println("各玩家身份：");
        for(int i = 0 ; i < 12; i++){
            System.out.print((i + 1) + " : " + data.getGamers()[i].getid() + "\t");
        }
        System.out.println();
    }
    
}

