/*
 * LoginView.java
 *
 * Created on __DATE__, __TIME__
 */

package go;

import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;

import game.Stage6;
import game.data6;
import game.menu6;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

/**
 *
 * @author  __USER__
 */
public class game63 extends javax.swing.JFrame implements ActionListener {

	public static  String shu = ("-1");
	public static String msg="";
	public static String msg2="";
	





	/** Creates new form LoginView */
	public game63() {
		initComponents();
	}
	
	public void initComponents() {
		jPanel1 = new javax.swing.JPanel();
		t1 = new java.awt.TextArea();
		t1.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 20));

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new Color(186, 85, 211));
		jPanel1.setForeground(new java.awt.Color(255, 102, 204));

		t1.setBackground(new java.awt.Color(204, 204, 255));
		
		t2 = new JTextField();
		t2.setColumns(10);
		
		btnNewButton = new JButton("返回");
		btnNewButton.addActionListener(this);
		btnNewButton.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		
		JButton btnNewButton_1 = new JButton("确定");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e ) {
				shu=t2.getText();
				t2.setText(null);
				

			}
		});
		btnNewButton_1.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		
		JLabel lblNewLabel = new JLabel("请输入你的选择：");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 20));
		
		p1 = new JLabel("");
        int width = 150,height = 170;	//这是图片和JLable的宽度和高度
        ImageIcon image = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\1.jpg");//实例化ImageIcon 对象
        image.setImage(image.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p1.setIcon(image);
        p1.setSize(width, height);
		
		p2 = new JLabel("");
		ImageIcon image1 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\2.jpg");//实例化ImageIcon 对象
        image1.setImage(image1.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p2.setIcon(image1);
        p2.setSize(width, height);
        
		p3 = new JLabel("");
		ImageIcon image2 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\3.jpg");//实例化ImageIcon 对象
        image2.setImage(image2.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p3.setIcon(image2);
        p3.setSize(width, height);
		
		p4 = new JLabel("");
		ImageIcon image3 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\4.jpg");//实例化ImageIcon 对象
        image3.setImage(image3.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p4.setIcon(image3);
        p4.setSize(width, height);
		
		p5 = new JLabel("");
		ImageIcon image4 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\5.jpg");//实例化ImageIcon 对象
        image4.setImage(image4.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p5.setIcon(image4);
        p5.setSize(width, height);
		
		p6 = new JLabel("");
		ImageIcon image5 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\6.jpg");//实例化ImageIcon 对象
        image5.setImage(image5.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p6.setIcon(image5);
        p6.setSize(width, height);

		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1Layout.setHorizontalGroup(
			jPanel1Layout.createParallelGroup(Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup()
					.addGap(41)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addComponent(p1, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
						.addComponent(p3, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
						.addComponent(p2, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE))
					.addGap(75)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED))
						.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
							.addGroup(jPanel1Layout.createSequentialGroup()
								.addGroup(jPanel1Layout.createParallelGroup(Alignment.TRAILING)
									.addGroup(jPanel1Layout.createSequentialGroup()
										.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(ComponentPlacement.RELATED, 217, Short.MAX_VALUE)
										.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE))
									.addComponent(t2, 693, 693, 693))
								.addGap(20))
							.addGroup(jPanel1Layout.createSequentialGroup()
								.addComponent(t1, GroupLayout.PREFERRED_SIZE, 693, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED))))
					.addGap(25)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addComponent(p4, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
						.addComponent(p6, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
						.addComponent(p5, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE))
					.addGap(65))
		);
		jPanel1Layout.setVerticalGroup(
			jPanel1Layout.createParallelGroup(Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup()
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addGap(48)
							.addComponent(t1, GroupLayout.PREFERRED_SIZE, 353, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
							.addComponent(lblNewLabel))
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addGap(80)
							.addComponent(p4, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
							.addGap(103)
							.addComponent(p5, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addGap(80)
							.addComponent(p1, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
							.addGap(94)
							.addComponent(p2, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addComponent(p3, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addComponent(t2, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
							.addGap(36)
							.addGroup(jPanel1Layout.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)))
						.addComponent(p6, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(77, Short.MAX_VALUE))
		);
		jPanel1.setLayout(jPanel1Layout);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		layout.setHorizontalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					.addContainerGap()
					.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGap(22))
		);
		layout.setVerticalGroup(
			layout.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, layout.createSequentialGroup()
					.addContainerGap()
					.addComponent(jPanel1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		getContentPane().setLayout(layout);

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		
		new game63().setVisible(true);
		

	}
	public void a() {
		
		new game63().setVisible(true);
		
		data6 data =  new data6();

        menu6 menu = new menu6(); 
        
        Stage6 stage = new Stage6();
        
        menu.welcome6(data,stage);
	}
	public javax.swing.JPanel jPanel1;
	public static java.awt.TextArea t1;

	public JTextField t2;
	private JButton btnNewButton;
	private JLabel p1;
	private JLabel p2;
	private JLabel p3;
	private JLabel p4;
	private JLabel p5;
	private JLabel p6;
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButton) {
			do_btnNewButton_actionPerformed(e);
		}
	}
	protected void do_btnNewButton_actionPerformed(ActionEvent e) {
		
	}
	
	
}