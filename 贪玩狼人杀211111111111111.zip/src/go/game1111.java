package go;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import game.Stage6;
import game.data6;
import game.menu6;

import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Button;
import javax.swing.JLabel;
import java.awt.event.TextListener;
import java.awt.event.TextEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class game1111 extends JFrame {
	public static  String shu = ("-1");
	public static String msg="111";
	public static String msg2="222";
	public static TextArea t1 = new TextArea();
	public static String msg3="222";
	private JPanel contentPane;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					game1111 frame = new game1111();
					frame.setVisible(true);
					if(msg2!=msg) {
						t1.setText(msg);
						msg2=msg;
					}
					else if (msg!="111") {
						t1.setText(msg);
						msg2=msg;
					}
					data6 data =  new data6();
	                menu6 menu = new menu6();       
	                Stage6 stage = new Stage6();
	                menu.welcome6(data,stage);
	                if(msg2!=msg) {
						t1.setText(msg);
						msg2=msg;
					}
					else if (msg!="111") {
						t1.setText(msg);
						msg2=msg;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public game1111() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 501);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		
		t1.addTextListener(new TextListener() {
			public void textValueChanged(TextEvent e) {

				

			}
		});
		t1.setBounds(64, 54, 500, 190);
		contentPane.add(t1);
		
		TextField t2 = new TextField();
		t2.setBounds(64, 299, 500, 25);
		contentPane.add(t2);
		
		Button button = new Button("New button");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				shu=t2.getText();
			}
		});
		button.setBounds(468, 391, 87, 25);
		contentPane.add(button);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(47, 13, 72, 18);
		contentPane.add(lblNewLabel);
	}

}
