package go;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;

public class gerenxinxi6 extends JFrame {
	public static String a="0";
	public static String b="0";
	public static String c="0";
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gerenxinxi6 frame = new gerenxinxi6();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public gerenxinxi6() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 548, 519);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel p1 = new JLabel("");
		p1.setBounds(49, 63, 84, 75);
		contentPane.add(p1);
        int width = 150,height = 170;	//这是图片和JLable的宽度和高度
        ImageIcon image = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\1.jpg");//实例化ImageIcon 对象
        image.setImage(image.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p1.setIcon(image);
        p1.setSize(width, height);
        
        JLabel lblNewLabel = new JLabel("游玩场数：");
        lblNewLabel.setFont(new Font("宋体", Font.BOLD, 20));
        lblNewLabel.setBounds(211, 29, 130, 98);
        contentPane.add(lblNewLabel);
        
        JLabel lblNewLabel_1 = new JLabel(String.valueOf(print6.a6) );
        lblNewLabel_1.setFont(new Font("宋体", Font.BOLD, 20));
        lblNewLabel_1.setBounds(328, 51, 98, 55);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("狼人胜场：");
        lblNewLabel_2.setFont(new Font("宋体", Font.BOLD, 20));
        lblNewLabel_2.setBounds(211, 151, 130, 98);
        contentPane.add(lblNewLabel_2);
        
        JLabel lblNewLabel_1_1 = new JLabel("New label");
        lblNewLabel_1_1.setFont(new Font("宋体", Font.BOLD, 20));
        lblNewLabel_1_1.setBounds(327, 175, 98, 55);
        contentPane.add(lblNewLabel_1_1);
        
        JLabel lblNewLabel_2_1 = new JLabel("好人胜场：");
        lblNewLabel_2_1.setFont(new Font("宋体", Font.BOLD, 20));
        lblNewLabel_2_1.setBounds(208, 282, 130, 98);
        contentPane.add(lblNewLabel_2_1);
        
        JLabel lblNewLabel_1_1_1 = new JLabel("New label");
        lblNewLabel_1_1_1.setFont(new Font("宋体", Font.BOLD, 20));
        lblNewLabel_1_1_1.setBounds(327, 310, 98, 55);
        contentPane.add(lblNewLabel_1_1_1);
        
        JLabel lblNewLabel_3 = new JLabel("昵称：6");
        lblNewLabel_3.setFont(new Font("宋体", Font.BOLD, 18));
        lblNewLabel_3.setBounds(51, 275, 72, 18);
        contentPane.add(lblNewLabel_3);
        
        JLabel lblNewLabel_3_1 = new JLabel("性别：男");
        lblNewLabel_3_1.setFont(new Font("宋体", Font.BOLD, 18));
        lblNewLabel_3_1.setBounds(49, 330, 103, 18);
        contentPane.add(lblNewLabel_3_1);
        
        JLabel lblNewLabel_3_2 = new JLabel("年龄：22");
        lblNewLabel_3_2.setFont(new Font("宋体", Font.BOLD, 18));
        lblNewLabel_3_2.setBounds(49, 384, 103, 18);
        contentPane.add(lblNewLabel_3_2);
	}
}
