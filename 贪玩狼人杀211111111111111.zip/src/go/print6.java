package go;

import java.util.Scanner;

import game.data6;

public class print6 {
	public static int a1=0;
	public static int a2=0;
	public static int a3=0;
	public static int a4=0;
	public static int a5=0;
	public static int a6=0;

    public static void printDot(int number){
    	
        for(int i = 0 ; i < number; i++){
            try{
                Thread.sleep(300);
            }catch (InterruptedException e){
            	
        		game6.msg+="游戏异常，正在退出...";
                game6.msg+="\n";
                game6.t1.setText(game6.msg);
            	
        		game61.msg+="游戏异常，正在退出...";
                game61.msg+="\n";
                game61.t1.setText(game61.msg);
            	
        		game62.msg+="游戏异常，正在退出...";
                game62.msg+="\n";
                game62.t1.setText(game62.msg);
            	
        		game63.msg+="游戏异常，正在退出...";
                game63.msg+="\n";
                game63.t1.setText(game63.msg);
            	
        		game64.msg+="游戏异常，正在退出...";
                game64.msg+="\n";
                game64.t1.setText(game64.msg);
            	
        		game65.msg+="游戏异常，正在退出...";
                game65.msg+="\n";
                game65.t1.setText(game65.msg);

            }
        }
        System.out.println();
    }
    
    public static void printIdentity6(data6 data){
    	a1++;
    	a2++;
    	a3++;
    	a4++;
    	a5++;
    	a6++;
		game6.msg+="各玩家身份：";
        game6.msg+="\n";
        game6.t1.setText(game6.msg);
    	
		game61.msg+="各玩家身份：";
        game61.msg+="\n";
        game61.t1.setText(game61.msg);
    	
		game62.msg+="各玩家身份：";
        game62.msg+="\n";
        game62.t1.setText(game62.msg);
    	
		game63.msg+="各玩家身份：";
        game63.msg+="\n";
        game63.t1.setText(game63.msg);
    	
		game64.msg+="各玩家身份：";
        game64.msg+="\n";
        game64.t1.setText(game64.msg);
    	
		game65.msg+="各玩家身份：";
        game65.msg+="\n";
        game65.t1.setText(game65.msg);
        
        for(int i = 0 ; i < 1; i++){
    		game6.msg+=(i + 1) + " : " + data.getGamers()[i].getid() + "\t";
            game6.msg+="\n";
            game6.t1.setText(game6.msg);
            if(data.getGamers()[i].getid()=="预言家") {
            	game.Stage6.sheng1=1;
            }
            if(data.getGamers()[i].getid()=="女巫") {
            	game.Stage6.nvwu1=1;
            }
            if(data.getGamers()[i].getid()=="狼人") {
            		game.Stage6.lang1=1;	
            }

           // System.out.print((i + 1) + " : " + data.getGamers()[i].getid() + "\t");
        }
        for(int i = 1 ; i < 2; i++){
    		game61.msg+=(i + 1) + " : " + data.getGamers()[i].getid() + "\t";
            game61.msg+="\n";
            game61.t1.setText(game61.msg);
            if(data.getGamers()[i].getid()=="预言家") {
            	game.Stage6.sheng1=2;
            }
            if(data.getGamers()[i].getid()=="女巫") {
            	game.Stage6.nvwu1=2;
            }
            if(data.getGamers()[i].getid()=="狼人") {
        		game.Stage6.lang1=2;	
        }

           // System.out.print((i + 1) + " : " + data.getGamers()[i].getid() + "\t");
        }
        for(int i = 2 ; i < 3; i++){
    		game62.msg+=(i + 1) + " : " + data.getGamers()[i].getid() + "\t";
            game62.msg+="\n";
            game62.t1.setText(game62.msg);
            if(data.getGamers()[i].getid()=="预言家") {
            	game.Stage6.sheng1=3;
            }
            if(data.getGamers()[i].getid()=="女巫") {
            	game.Stage6.nvwu1=3;
            }
            if(data.getGamers()[i].getid()=="狼人") {
        		game.Stage6.lang1=3;	
        }

           // System.out.print((i + 1) + " : " + data.getGamers()[i].getid() + "\t");
        }
        for(int i = 3 ; i < 4; i++){
    		game63.msg+=(i + 1) + " : " + data.getGamers()[i].getid() + "\t";
            game63.msg+="\n";
            game63.t1.setText(game63.msg);
            if(data.getGamers()[i].getid()=="预言家") {
            	game.Stage6.sheng1=4;
            }
            if(data.getGamers()[i].getid()=="女巫") {
            	game.Stage6.nvwu1=4;
            }
            if(data.getGamers()[i].getid()=="狼人") {
        		game.Stage6.lang1=4;	
        }

           // System.out.print((i + 1) + " : " + data.getGamers()[i].getid() + "\t");
        }
        for(int i = 4 ; i < 5; i++){
    		game64.msg+=(i + 1) + " : " + data.getGamers()[i].getid() + "\t";
            game64.msg+="\n";
            game64.t1.setText(game64.msg);
            if(data.getGamers()[i].getid()=="预言家") {
            	game.Stage6.sheng1=5;
            }
            if(data.getGamers()[i].getid()=="女巫") {
            	game.Stage6.nvwu1=5;
            }
            if(data.getGamers()[i].getid()=="狼人") {
        		game.Stage6.lang1=5;	
        }

           // System.out.print((i + 1) + " : " + data.getGamers()[i].getid() + "\t");
        }
        for(int i = 5 ; i < 6; i++){
    		game65.msg+=(i + 1) + " : " + data.getGamers()[i].getid() + "\t";
            game65.msg+="\n";
            game65.t1.setText(game65.msg);
            if(data.getGamers()[i].getid()=="预言家") {
            	game.Stage6.sheng1=6;
            }
            if(data.getGamers()[i].getid()=="女巫") {
            	game.Stage6.nvwu1=6;
            }
            if(data.getGamers()[i].getid()=="狼人") {
        		game.Stage6.lang1=6;	
        }

           // System.out.print((i + 1) + " : " + data.getGamers()[i].getid() + "\t");
        }
        
        System.out.println();

        
    }
    
}

