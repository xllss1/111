package go;

import game.data9;

public class print9 {

    public static void printDot(int number){
        for(int i = 0 ; i < number; i++){
            try{
                Thread.sleep(300);
            }catch (InterruptedException e){
                System.out.println("游戏异常，正在退出...");
                System.exit(0);
            }
        }
        System.out.println();
    }
    
    public static void printIdentity9(data9 data){
        System.out.println("各玩家身份：");
        for(int i = 0 ; i < 9; i++){
            System.out.print((i + 1) + " : " + data.getGamers()[i].getid() + "\t");
        }
        System.out.println();
    }
    
}

