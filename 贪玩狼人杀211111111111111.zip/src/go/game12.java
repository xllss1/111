/*
 * LoginView.java
 *
 * Created on __DATE__, __TIME__
 */

package go;

import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.GroupLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 *
 * @author  __USER__
 */
public class game12 extends javax.swing.JFrame implements ActionListener {
	public static  String shu = ("-1");
	public static String msg="";
	public static String msg2="";

	/** Creates new form LoginView */
	public game12() {
		initComponents();
	}
	

	//GEN-BEGIN:initComponents
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	public void initComponents() {

		jPanel1 = new javax.swing.JPanel();
		t1 = new java.awt.TextArea();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel1.setBackground(new Color(186, 85, 211));
		jPanel1.setForeground(new java.awt.Color(255, 102, 204));

		t1.setBackground(new java.awt.Color(204, 204, 255));
		
		t2 = new JTextField();
		t2.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("请输入你的选择：");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		
		btnNewButton = new JButton("返回");
		btnNewButton.addActionListener(this);
		btnNewButton.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		
		JButton btnNewButton_1 = new JButton("确定");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				shu=t2.getText();
				t2.setText(null);
				
			}
		});
		btnNewButton_1.setFont(new Font("Lucida Grande", Font.PLAIN, 18));
		
		p1 = new JLabel("");
        int width = 150,height = 170;	//这是图片和JLable的宽度和高度
        ImageIcon image = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\1.jpg");//实例化ImageIcon 对象
        image.setImage(image.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p1.setIcon(image);
        p1.setSize(width, height);
		
		p2 = new JLabel("");
		ImageIcon image1 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\2.jpg");//实例化ImageIcon 对象
        image1.setImage(image1.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p2.setIcon(image1);
        p2.setSize(width, height);
        
		p3 = new JLabel("");
		ImageIcon image2 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\3.jpg");//实例化ImageIcon 对象
        image2.setImage(image2.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p3.setIcon(image2);
        p3.setSize(width, height);
		
		p4 = new JLabel("");
		ImageIcon image3 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\4.jpg");//实例化ImageIcon 对象
        image3.setImage(image3.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p4.setIcon(image3);
        p4.setSize(width, height);
		
		p5 = new JLabel("");
		ImageIcon image4 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\5.jpg");//实例化ImageIcon 对象
        image4.setImage(image4.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p5.setIcon(image4);
        p5.setSize(width, height);
		
		p6 = new JLabel("");
		ImageIcon image5 = new ImageIcon("C:\\Users\\13592\\Desktop\\策划部会议纪要\\请假条\\6.jpg");//实例化ImageIcon 对象
        image5.setImage(image5.getImage().getScaledInstance(width, height,Image.SCALE_DEFAULT ));
        p6.setIcon(image5);
        p6.setSize(width, height);
		
        
		p7 = new JLabel("");
        p7.setIcon(image);
        p7.setSize(width, height);
		p8 = new JLabel("");
        p8.setIcon(image1);
        p8.setSize(width, height);
		p9 = new JLabel("");
        p9.setIcon(image2);
        p9.setSize(width, height);
		p10 = new JLabel("");
        p10.setIcon(image2);
        p10.setSize(width, height);
		p11 = new JLabel("");
        p11.setIcon(image3);
        p11.setSize(width, height);
		p12 = new JLabel("");
        p12.setIcon(image4);
        p12.setSize(width, height);
		javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(
				jPanel1);
		jPanel1Layout.setHorizontalGroup(
			jPanel1Layout.createParallelGroup(Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup()
					.addGap(46)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addComponent(p1)
						.addComponent(p5)
						.addComponent(p6)
						.addComponent(p4)
						.addComponent(p3)
						.addComponent(p2))
					.addGap(56)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addGap(30)
							.addComponent(t1, GroupLayout.PREFERRED_SIZE, 693, GroupLayout.PREFERRED_SIZE))
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED, 573, Short.MAX_VALUE))
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
								.addGroup(jPanel1Layout.createSequentialGroup()
									.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 262, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 195, Short.MAX_VALUE)
									.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 262, GroupLayout.PREFERRED_SIZE))
								.addComponent(t2, 719, 719, 719))))
					.addGap(42)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addComponent(p7)
						.addComponent(p8)
						.addComponent(p9)
						.addComponent(p10)
						.addComponent(p11)
						.addComponent(p12))
					.addGap(64))
		);
		jPanel1Layout.setVerticalGroup(
			jPanel1Layout.createParallelGroup(Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup()
					.addGap(12)
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING, false)
								.addGroup(jPanel1Layout.createSequentialGroup()
									.addComponent(t1, GroupLayout.PREFERRED_SIZE, 479, GroupLayout.PREFERRED_SIZE)
									.addGap(24)
									.addComponent(lblNewLabel)
									.addPreferredGap(ComponentPlacement.UNRELATED))
								.addGroup(jPanel1Layout.createSequentialGroup()
									.addComponent(p1, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(p2, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
									.addGap(39)
									.addComponent(p3, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
									.addGap(32)
									.addComponent(p4, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
									.addGap(36)
									.addComponent(p6, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
									.addGap(32)))
							.addGap(13))
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addComponent(p7, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
							.addGap(57)
							.addComponent(p11, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
							.addGap(34)
							.addComponent(p12, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
							.addComponent(p10, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(p9, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
							.addGap(36)))
					.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
						.addComponent(p8, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
						.addGroup(jPanel1Layout.createSequentialGroup()
							.addComponent(t2, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(jPanel1Layout.createParallelGroup(Alignment.LEADING)
								.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)))
						.addComponent(p5, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(87, Short.MAX_VALUE))
		);
		jPanel1.setLayout(jPanel1Layout);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(
				getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(layout.createParallelGroup(
				javax.swing.GroupLayout.Alignment.LEADING).addComponent(
				jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE,
				javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>
	//GEN-END:initComponents

	public void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new game12().setVisible(true);
			}
		});
	}
	public javax.swing.JPanel jPanel1;
	public static java.awt.TextArea t1;
	public JTextField t2;
	public JButton btnNewButton;
	private JLabel p1;
	private JLabel p2;
	private JLabel p3;
	private JLabel p4;
	private JLabel p5;
	private JLabel p6;
	private JLabel p7;
	private JLabel p8;
	private JLabel p9;
	private JLabel p10;
	private JLabel p11;
	private JLabel p12;
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnNewButton) {
			do_btnNewButton_actionPerformed(e);
		}
	}
	protected void do_btnNewButton_actionPerformed(ActionEvent e) {
		new LoginView().setVisible(true);
		dispose();
	}
}